-- MySQL dump 10.13  Distrib 5.7.43, for Linux (aarch64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	5.7.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artwork`
--

DROP TABLE IF EXISTS `artwork`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artwork` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `price` float DEFAULT NULL,
  `sold` tinyint(1) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `media` int(11) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artwork`
--

LOCK TABLES `artwork` WRITE;
/*!40000 ALTER TABLE `artwork` DISABLE KEYS */;
INSERT INTO `artwork` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL),(3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,NULL),(4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,NULL),(5,NULL,NULL,NULL,NULL,NULL,0,NULL,16,NULL);
/*!40000 ALTER TABLE `artwork` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `upload_path` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `size_key` varchar(11) DEFAULT NULL,
  `media` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `ratio` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'IMG_1863_0c2e71.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1863_0c2e71.jpeg','original',NULL,5712,4284,1.33333),(2,'IMG_1863_0c2e71_lg.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1863_0c2e71_lg.jpeg','lg',1,1280,960,1.33333),(3,'IMG_1863_0c2e71_thumb.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1863_0c2e71_thumb.jpeg','thumb',1,400,300,1.33333),(4,'IMG_1861_73b5c5.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1861_73b5c5.jpeg','original',NULL,5712,4284,1.33333),(5,'IMG_1861_73b5c5_lg.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1861_73b5c5_lg.jpeg','lg',4,1280,960,1.33333),(6,'IMG_1861_73b5c5_thumb.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1861_73b5c5_thumb.jpeg','thumb',4,400,300,1.33333),(7,'IMG_1863_342550.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1863_342550.jpeg','original',NULL,5712,4284,1.33333),(8,'IMG_1863_342550_lg.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1863_342550_lg.jpeg','lg',7,1280,960,1.33333),(9,'IMG_1863_342550_thumb.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1863_342550_thumb.jpeg','thumb',7,400,300,1.33333),(10,'IMG_1861_16ecd2.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1861_16ecd2.jpeg','original',NULL,5712,4284,1.33333),(11,'IMG_1861_16ecd2_lg.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1861_16ecd2_lg.jpeg','lg',10,1280,960,1.33333),(12,'IMG_1861_16ecd2_thumb.jpeg','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/IMG_1861_16ecd2_thumb.jpeg','thumb',10,400,300,1.33333),(13,'ChatGPT Image May 12, 2025, 03_21_07 PM_9f46cf.png','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/ChatGPT Image May 12, 2025, 03_21_07 PM_9f46cf.png','original',NULL,1024,1536,0.666667),(14,'ChatGPT Image May 12, 2025, 03_21_07 PM_9f46cf_lg.png','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/ChatGPT Image May 12, 2025, 03_21_07 PM_9f46cf_lg.png','lg',13,640,960,0.666667),(15,'ChatGPT Image May 12, 2025, 03_21_07 PM_9f46cf_thumb.png','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/ChatGPT Image May 12, 2025, 03_21_07 PM_9f46cf_thumb.png','thumb',13,200,300,0.666667),(16,'ChatGPT Image May 12, 2025, 03_21_07 PM_4aa9bd.png','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/ChatGPT Image May 12, 2025, 03_21_07 PM_4aa9bd.png','original',NULL,1024,1536,0.666667),(17,'ChatGPT Image May 12, 2025, 03_21_07 PM_4aa9bd_lg.png','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/ChatGPT Image May 12, 2025, 03_21_07 PM_4aa9bd_lg.png','lg',16,640,960,0.666667),(18,'ChatGPT Image May 12, 2025, 03_21_07 PM_4aa9bd_thumb.png','/app/uploads/2025/05/','https://rw-api.lndo.site/uploads/2025/05/ChatGPT Image May 12, 2025, 03_21_07 PM_4aa9bd_thumb.png','thumb',16,200,300,0.666667);
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-12 19:45:23
